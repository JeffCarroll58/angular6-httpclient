import { Component, OnInit, Input , Output, EventEmitter } from '@angular/core';
import { RestService } from '../rest.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';


@Component({
  selector: 'app-product-add',
  templateUrl: './product-add.component.html',
  styleUrls: ['./product-add.component.css']
})
export class ProductAddComponent implements OnInit {

    addForm: FormGroup;
    submitted = false;



    constructor(private formBuilder: FormBuilder, public rest:RestService, private route: ActivatedRoute, private router: Router) { }




    ngOnInit() {


        let  numericPattern = '^[1-9]\\d*(\\.\\d+)?$';

        this.addForm = this.formBuilder.group({
          id: [],
          prod_name: ['', Validators.required],
          prod_desc: ['', Validators.required],
          prod_price: ['', [
              Validators.required,
              Validators.pattern(numericPattern)
              ]
          ]
      });

    }

    // not used
    isInvalid(name: string) {

          const control = this.addForm.get(name);
          return control.invalid && control.dirty;

      }

    // convenience getter for easy access to form fields
    get f() { return this.addForm.controls; }


    onSubmit() {

        this.submitted = true;

      // stop here if form is invalid
        if (this.addForm.invalid) {
            return;
        }


        this.rest.addProduct(this.addForm.value).subscribe((result) => {
              console.log('addProduct');
              console.log(result);
              this.router.navigate(['']);
          }, (err) => {
              console.log(err);
          });

      }

      onCancel() {
          this.router.navigate(['']);
      }


}
